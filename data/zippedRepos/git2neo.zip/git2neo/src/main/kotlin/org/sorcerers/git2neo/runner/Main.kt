package org.sorcerers.git2neo.runner

fun main(args: Array<String>) {
    println("test")
}